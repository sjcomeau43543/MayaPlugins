# =====================================================================
# Author : Chayan Vinayak
# Copyright Chayan Vinayak
#
# =====================================================================

import maya.OpenMaya as OpenMaya

# 1. Create a Selection List
mSel = OpenMaya.MSelectionList()
mSel.add("pPlane1")

# 2. Create MObject and MDagPath
mObj = OpenMaya.MObject()
mDagPath = OpenMaya.MDagPath()

# 3. Request Dependency Node and Dag Path of the object
mSel.getDependNode(0,mObj)
mSel.getDagPath(0,mDagPath)
print mDagPath.fullPathName()

# 4. Mesh function set
mFnMesh = OpenMaya.MFnMesh(mDagPath)
print mFnMesh.fullPathName()

# 5. Dependency Node function set
mFnDependNode = OpenMaya.MFnDependencyNode(mObj)
print mFnDependNode.name()

# 6. Get all the connections of a Shape node
mPlugArray = OpenMaya.MPlugArray()
mFnMesh.getConnections(mPlugArray)

mPlugArray.length()
print mPlugArray[0].name()
print mPlugArray[1].name()

mPlugArray2 = OpenMaya.MPlugArray()
mPlugArray[1].connectedTo(mPlugArray2,True,False)

mPlugArray2.length()
# Can not be used : len(mPlugArray2)

print mPlugArray2[0].name()
mObj2 = mPlugArray2[0].node()
mFnDependNode2 = OpenMaya.MFnDependencyNode(mObj2)
print mFnDependNode2.name()

mPlug_width = mFnDependNode2.findPlug("width")
mPlug_height = mFnDependNode2.findPlug("height")
print mPlug_width.asInt()
print mPlug_height.asInt()

mPlug_subWidth = mFnDependNode2.findPlug("subdivisionsWidth")
mPlug_subHeight = mFnDependNode2.findPlug("subdivisionsHeight")

mPlug_subWidth.setInt(10)
mPlug_subHeight.setInt(10)

