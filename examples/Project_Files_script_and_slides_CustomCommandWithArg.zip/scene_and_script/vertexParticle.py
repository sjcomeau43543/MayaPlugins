# =====================================================================
# Author : Chayan Vinayak
# Copyright Chayan Vinayak
#
# =====================================================================

import sys
import maya.OpenMaya as OpenMaya
import maya.OpenMayaMPx as OpenMayaMPx
import maya.OpenMayaFX as OpenMayaFX


commandName = "vertexParticle"

kHelpFlag = "-h"
kHelpLongFlag = "-help"
kSparseFlag = "-s"
kSparseLongFlag = "-sparse"
helpMessage = "This command is used to attach a particle on each vertex of a poly mesh"

class pluginCommand(OpenMayaMPx.MPxCommand):

    sparse = None
    def __init__(self):
        OpenMayaMPx.MPxCommand.__init__(self)

    def argumentParser(self,argList):   	
	syntax = self.syntax()
	try:
		parsedArguments = OpenMaya.MArgDatabase(syntax,argList)
	except:
		print "Incorrect Argument" 
		return OpenMaya.MStatus.kUnknownParameter
	if parsedArguments.isFlagSet(kSparseFlag):
		self.sparse = parsedArguments.flagArgumentDouble(kSparseFlag,0)
		return OpenMaya.MStatus.kSuccess
	if parsedArguments.isFlagSet(kSparseLongFlag):
		self.sparse = parsedArguments.flagArgumentDouble(kSparseLongFlag,0)
		return OpenMaya.MStatus.kSuccess
	if parsedArguments.isFlagSet(kHelpFlag):
		self.setResult(helpMessage)
		return OpenMaya.MStatus.kSuccess
	if parsedArguments.isFlagSet(kHelpLongFlag):
		self.setResult(helpMessage)
		return OpenMaya.MStatus.kSuccess        	
        	
    def isUndoable(self):
        return True 	
    
    def undoIt(self):
        print "undo"
        mFnDagNode = OpenMaya.MFnDagNode(self.mObj_particle)
        mDagMod = OpenMaya.MDagModifier()
        mDagMod.deleteNode(mFnDagNode.parent(0))
        mDagMod.doIt()
        return OpenMaya.MStatus.kSuccess  	
    	
    def redoIt(self):
        mSel = OpenMaya.MSelectionList()
        mDagPath = OpenMaya.MDagPath()
        mFnMesh = OpenMaya.MFnMesh()
        OpenMaya.MGlobal.getActiveSelectionList(mSel)
        if mSel.length() >=1:
        	try:
        		mSel.getDagPath(0,mDagPath)
        		mFnMesh.setObject(mDagPath)
        	except:
        		print "Select a poly mesh"
        		return OpenMaya.MStatus.kUnknownParameter
        else:
        	print "Select a poly mesh"
        	return OpenMaya.MStatus.kUnknownParameter
        
        mPointArray = OpenMaya.MPointArray()
        mFnMesh.getPoints(mPointArray,OpenMaya.MSpace.kWorld)
        # Create a particle system
        mFnParticle = OpenMayaFX.MFnParticleSystem()
        self.mObj_particle = mFnParticle.create()
        # To fix Maya bug 
        mFnParticle = OpenMayaFX.MFnParticleSystem(self.mObj_particle)
        counter=0
        for i in xrange(mPointArray.length()):
        	if i%self.sparse==0:
        		mFnParticle.emit(mPointArray[i])
        		counter+=1
        print "Total Points :" + str(counter)
        mFnParticle.saveInitialState()
        return OpenMaya.MStatus.kSuccess
        		
    def doIt(self,argList):
        print "doIt..."
        self.argumentParser(argList)
        if self.sparse !=None:
        	self.redoIt()
        return OpenMaya.MStatus.kSuccess

# Creator
def cmdCreator():
    return OpenMayaMPx.asMPxPtr( pluginCommand() )

def syntaxCreator():
	# create MSyntax object
	syntax = OpenMaya.MSyntax()
	# collect/add the flags
	syntax.addFlag(kHelpFlag,kHelpLongFlag)
	syntax.addFlag(kSparseFlag,kSparseLongFlag,OpenMaya.MSyntax.kDouble)
	# return MSyntax
	return syntax

# Initialize the script plug-in
def initializePlugin(mobject):
    mplugin = OpenMayaMPx.MFnPlugin(mobject)
    try:
        mplugin.registerCommand( commandName, cmdCreator ,syntaxCreator)
    except:
        sys.stderr.write( "Failed to register command: %s\n" % commandName )

# Uninitialize the script plug-in
def uninitializePlugin(mobject):
    mplugin = OpenMayaMPx.MFnPlugin(mobject)
    try:
        mplugin.deregisterCommand( commandName )
    except:
        sys.stderr.write( "Failed to unregister command: %s\n" % commandName )